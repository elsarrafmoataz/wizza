import { useRef, useState } from "react";
import { Modal, View, Text, Pressable, StyleSheet, PanResponder, ActivityIndicator, Alert } from "react-native";
import MapView, { Marker, Circle as MapCircle, Region } from "react-native-maps";
import * as Location from "expo-location";
import Svg, { Path, Circle } from "react-native-svg";
import { LocationPermissionGate } from "./LocationPermissionGate";
import { useLanguage } from "../../lib/hooks/useLanguage";

// ↔ modal-geo-search / geoDraft / useMyCurrentLocation() / applyGeoSearch() /
// clearGeoSearch() in app-viewer.html. The web version used a Leaflet map
// with a draggable radius circle; react-native-maps' <Circle> + a draggable
// <Marker> reproduce the same interaction on native.

export type GeoPoint = { lat: number; lng: number; radiusKm: number } | null;

type Props = {
  visible: boolean;
  value: GeoPoint;
  onApply: (point: GeoPoint) => void;
  onClose: () => void;
};

const DEFAULT_REGION: Region = { latitude: 30.0444, longitude: 31.2357, latitudeDelta: 0.3, longitudeDelta: 0.3 }; // Cairo
const MIN_RADIUS = 1;
const MAX_RADIUS = 50;

export function GeoSearchModal({ visible, value, onApply, onClose }: Props) {
  const { t } = useLanguage();
  const [point, setPoint] = useState<{ lat: number; lng: number } | null>(
    value ? { lat: value.lat, lng: value.lng } : null
  );
  const [radiusKm, setRadiusKm] = useState(value?.radiusKm ?? 10);
  const [region, setRegion] = useState<Region>(
    value ? { ...DEFAULT_REGION, latitude: value.lat, longitude: value.lng } : DEFAULT_REGION
  );
  const [locating, setLocating] = useState(false);

  async function useMyCurrentLocation() {
    setLocating(true);
    try {
      const pos = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
      const next = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      setPoint(next);
      setRegion({ latitude: next.lat, longitude: next.lng, latitudeDelta: 0.15, longitudeDelta: 0.15 });
    } catch {
      Alert.alert(t("تعذر تحديد الموقع"), t("حاول مرة أخرى أو اختر نقطة على الخريطة يدويًا."));
    } finally {
      setLocating(false);
    }
  }

  function apply() {
    if (!point) {
      Alert.alert(t("اختر نقطة على الخريطة أو استخدم موقعك الحالي"));
      return;
    }
    onApply({ lat: point.lat, lng: point.lng, radiusKm });
    onClose();
  }

  function clear() {
    setPoint(null);
    onApply(null);
    onClose();
  }

  return (
    <Modal visible={visible} animationType="slide" onRequestClose={onClose}>
      <LocationPermissionGate>
        <View style={styles.container}>
          <View style={styles.header}>
            <Pressable style={styles.closeBtn} onPress={onClose} hitSlop={8}>
              <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="#111" strokeWidth={2}><Path d="M18 6L6 18M6 6l12 12" /></Svg>
            </Pressable>
            <Text style={styles.headerTitle}>{t("البحث بالموقع")}</Text>
            <View style={{ width: 34 }} />
          </View>

          <MapView
            style={{ flex: 1 }}
            initialRegion={region}
            region={region}
            onRegionChangeComplete={setRegion}
            onPress={(e) => setPoint({ lat: e.nativeEvent.coordinate.latitude, lng: e.nativeEvent.coordinate.longitude })}
          >
            {point && (
              <>
                <Marker
                  coordinate={{ latitude: point.lat, longitude: point.lng }}
                  draggable
                  onDragEnd={(e) => setPoint({ lat: e.nativeEvent.coordinate.latitude, lng: e.nativeEvent.coordinate.longitude })}
                />
                <MapCircle
                  center={{ latitude: point.lat, longitude: point.lng }}
                  radius={radiusKm * 1000}
                  strokeColor="#22A652"
                  fillColor="rgba(34,166,82,0.15)"
                  strokeWidth={2}
                />
              </>
            )}
          </MapView>

          <View style={styles.panel}>
            <Pressable style={styles.locateBtn} onPress={useMyCurrentLocation} disabled={locating}>
              {locating ? (
                <ActivityIndicator color="#22A652" size="small" />
              ) : (
                <Svg width={16} height={16} viewBox="0 0 24 24" fill="none" stroke="#22A652" strokeWidth={2}>
                  <Path d="M21 10c0 7-9 12-9 12s-9-5-9-12a9 9 0 0118 0z" /><Circle cx={12} cy={10} r={3} />
                </Svg>
              )}
              <Text style={styles.locateBtnText}>{t("استخدم موقعي الحالي")}</Text>
            </Pressable>

            <View style={styles.radiusRow}>
              <Text style={styles.radiusLabel}>{t("نطاق البحث")}</Text>
              <Text style={styles.radiusValue}>{radiusKm} {t("كم")}</Text>
            </View>
            <RadiusSlider value={radiusKm} min={MIN_RADIUS} max={MAX_RADIUS} onChange={setRadiusKm} />

            <View style={styles.actionsRow}>
              <Pressable style={styles.clearBtn} onPress={clear}>
                <Text style={styles.clearBtnText}>{t("إلغاء البحث بالموقع")}</Text>
              </Pressable>
              <Pressable style={[styles.applyBtn, !point && styles.applyBtnDisabled]} onPress={apply} disabled={!point}>
                <Text style={styles.applyBtnText}>{t("تطبيق")}</Text>
              </Pressable>
            </View>
          </View>
        </View>
      </LocationPermissionGate>
    </Modal>
  );
}

function RadiusSlider({ value, min, max, onChange }: { value: number; min: number; max: number; onChange: (v: number) => void }) {
  const trackWidth = useRef(0);
  const pct = (value - min) / (max - min);

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => true,
      onMoveShouldSetPanResponder: () => true,
      onPanResponderMove: (e) => handle(e.nativeEvent.locationX),
      onPanResponderGrant: (e) => handle(e.nativeEvent.locationX),
    })
  ).current;

  function handle(x: number) {
    if (!trackWidth.current) return;
    const p = Math.max(0, Math.min(1, x / trackWidth.current));
    onChange(Math.round(min + p * (max - min)));
  }

  return (
    <View
      style={styles.sliderTrack}
      onLayout={(e) => { trackWidth.current = e.nativeEvent.layout.width; }}
      {...panResponder.panHandlers}
    >
      <View style={styles.sliderBase} />
      <View style={[styles.sliderFill, { width: `${pct * 100}%` }]} />
      <View style={[styles.sliderThumb, { left: `${pct * 100}%` }]} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "white" },
  header: { paddingTop: 50, paddingBottom: 12, paddingHorizontal: 16, flexDirection: "row", alignItems: "center", justifyContent: "space-between", borderBottomWidth: 1, borderBottomColor: "#f3f4f6" },
  closeBtn: { width: 34, height: 34, borderRadius: 17, backgroundColor: "#f3f4f6", alignItems: "center", justifyContent: "center" },
  headerTitle: { fontSize: 14, fontWeight: "900", color: "#111827" },
  panel: { padding: 16, paddingBottom: 24, borderTopWidth: 1, borderTopColor: "#f3f4f6", gap: 10 },
  locateBtn: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, backgroundColor: "#ECFDF5", borderRadius: 12, paddingVertical: 12 },
  locateBtnText: { color: "#22A652", fontWeight: "900", fontSize: 13 },
  radiusRow: { flexDirection: "row", justifyContent: "space-between", marginTop: 6 },
  radiusLabel: { fontSize: 12.5, fontWeight: "800", color: "#374151" },
  radiusValue: { fontSize: 12.5, fontWeight: "900", color: "#22A652" },
  sliderTrack: { height: 30, justifyContent: "center" },
  sliderBase: { position: "absolute", left: 0, right: 0, height: 5, borderRadius: 3, backgroundColor: "#e5e7eb" },
  sliderFill: { position: "absolute", left: 0, height: 5, borderRadius: 3, backgroundColor: "#22A652" },
  sliderThumb: { position: "absolute", top: "50%", marginTop: -9, marginLeft: -9, width: 18, height: 18, borderRadius: 9, backgroundColor: "#22A652", borderWidth: 2, borderColor: "white" },
  actionsRow: { flexDirection: "row", gap: 10, marginTop: 8 },
  clearBtn: { flex: 1, borderRadius: 999, paddingVertical: 13, alignItems: "center", borderWidth: 1, borderColor: "#e5e7eb" },
  clearBtnText: { fontSize: 12.5, fontWeight: "900", color: "#374151" },
  applyBtn: { flex: 1, borderRadius: 999, paddingVertical: 13, alignItems: "center", backgroundColor: "#22A652" },
  applyBtnDisabled: { backgroundColor: "#a7d9bb" },
  applyBtnText: { fontSize: 12.5, fontWeight: "900", color: "white" },
});
